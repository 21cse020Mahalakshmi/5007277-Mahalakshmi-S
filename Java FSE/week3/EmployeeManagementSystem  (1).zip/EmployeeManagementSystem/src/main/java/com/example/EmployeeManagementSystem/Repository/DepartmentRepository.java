package com.example.EmployeeManagementSystem.Repository;
import com.example.EmployeeManagementSystem.*;
import org.springframework.data.jpa.repository.*;

public interface DepartmentRepository extends JpaRepository<Department,String>{
	Department findByName(@Param("name")String Name);
}
